
# 1. Create an array: [2, 4, 6, 8, 10]

import numpy as np

arr = np.array([2, 4, 6, 8, 10])
print(arr)


# 2. Multiply all elements by 3

arr = np.array([2, 4, 6, 8, 10])
arr = arr * 3
print(arr)


# 3. Find the average, sum, and standard deviation

arr = np.array([2, 4, 6, 8, 10])
print("Average:", np.mean(arr))
print("Sum:", np.sum(arr))
print("Standard Deviation:", np.std(arr))
