# Simulate 100 coin flips (0 = heads, 1 = tails)

import numpy as np

coin_flips = np.random.randint(0, 2, size=100)


heads_count = np.sum(coin_flips == 0)
tails_count = np.sum(coin_flips == 1)
print(f"Heads: {heads_count}, Tails: {tails_count}")



