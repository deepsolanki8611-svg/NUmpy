# 1. Create array a = [1, 2, 3, 4]

import numpy as np

a = np.array([1, 2, 3, 4])
print(a)

# 2. Add 5 to each element (broadcasting)

a = np.array([1, 2, 3, 4])
a = a + 5
print(a)


# 3. Calculate square and square root (ufuncs)

a = np.array([1, 2, 3, 4])
print(np.square(a))
print(np.sqrt(a))

