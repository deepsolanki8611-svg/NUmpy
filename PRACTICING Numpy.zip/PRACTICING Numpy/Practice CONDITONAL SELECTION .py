# 1. Create arr = [10, 15, 20, 25, 30]

import numpy as np

arr = np.array([10, 15, 20, 25, 30])
print(arr)


# 2. Select values greater than 18

arr = np.array([10, 15, 20, 25, 30])
print(arr[arr > 18])  # returns the elements that satisfy the condition


# 3. Replace values less than 18 with -1

arr = np.array([10, 15, 20, 25, 30])
arr[arr < 18] = -1  # Set values less than 18 to -1
print(arr)
