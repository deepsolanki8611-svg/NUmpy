# 1. Create a 1D array from 1 to 12. 

import numpy as np

a = np.arange(1, 13)  # Create a 1D array from 1 to 12
print(a)
 
# 2. Reshape it to 3x4.

b = a.reshape(3, 4)  # Reshape to 3 rows and 4 columns
print(b)
  
# 3. Flatten it back to 1D.

c = b.flatten()  # Flatten back to 1D
print(c)

  
# 4. Stack two 1D arrays vertically and horizontally.

a1 = np.array([1, 2, 3])
a2 = np.array([4, 5, 6])
# Stack vertically
v_stack = np.vstack((a1, a2))
print("Vertical Stack:")
print(v_stack)
# Stack horizontally
h_stack = np.hstack((a1, a2))   
print("Horizontal Stack:")
print(h_stack)
