
# 1. Create a 2D array: [[10, 20, 30], [40, 50, 60]]

import numpy as np

arr = np.array([[10, 20, 30], [40, 50, 60]])
print(arr)


# 2. Change the first row, second element to 999

arr = np.array([[10, 20, 30], [40, 50, 60]])
arr[0, 1] = 999
print(arr)


# 3. Replace the entire second row with [100, 200, 300]

arr = np.array([[10, 20, 30], [40, 50, 60]])
arr[1] = [100, 200, 300]
print(arr)
