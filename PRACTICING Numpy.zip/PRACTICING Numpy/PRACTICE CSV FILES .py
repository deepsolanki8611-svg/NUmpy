# 1. Load 'sales.csv' with columns: product, price, quantity 

import numpy as np

data = np.genfromtxt(
    r'D:\INTERNSHIP\Python\NUMPY\PRACTICING Numpy\sales.csv',
    delimiter=',',
    names=True,
    dtype=None,
    encoding=None
)

print("Sales Data:")
print(data)

# 2. Calculate average price and total quantity

average_price = np.mean(data['price'])
total_quantity = np.sum(data['quantity'])

print(f'Average Price: {average_price}')
print(f'Total Quantity: {total_quantity}')


# 3. Save the result to 'summary.csv'

summary = np.array(
    [(average_price, total_quantity)],
    dtype=[('Average Price', 'f8'), ('Total Quantity', 'i4')]
)

np.savetxt(
    r'D:\INTERNSHIP\Python\NUMPY\PRACTICING Numpy\summary.csv',
    summary,
    delimiter=',',
    fmt=['%.2f', '%d'],
    header='Average Price,Total Quantity',
    comments=''
)

print("Summary saved successfully to summary.csv")
